﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApplication3.Controllers;

namespace WebApplication3.Controllers
{
    public class AccController : Controller
    {
        public object Welcome { get; private set; }

        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Login(Accviewmodel avm)
        {
            if (avm.acc.username.Equals("abc") && avm.acc.password.Equals("123"))
            {
                Session["Username"] = avm.acc.username;
                return View(Welcome);
            }
            else
            {
                ViewBag.Error = "Account is Invalid";
                return View(Index);
            }

        }

        private ActionResult View(Func<ActionResult> index)
        {
            throw new NotImplementedException();
        }

        private ActionResult View(object welcome)
        {
            throw new NotImplementedException();
        }
    }
}